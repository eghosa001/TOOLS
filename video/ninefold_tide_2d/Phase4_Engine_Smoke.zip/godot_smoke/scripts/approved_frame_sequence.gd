extends Node2D
## Strictly 2D playback of individually reviewed full-canvas drawings.
## Does not synthesize frames, scale bodies or interpolate missing artwork.
## An unapproved shot stays blank with an obvious warning.
@export var shot_id: String = "E101_CAM03B_5S"
@export var autoplay_approved: bool = false
@export var show_review_status: bool = true

var manifest: Dictionary = {}
var cache: Dictionary = {}
var cache_order: Array[int] = []
var display_sprite: Sprite2D
var status_label: Label
var elapsed: float = 0.0
var current_frame: int = -1
var playing: bool = false
const CACHE_LIMIT: int = 6

func _ready() -> void:
    display_sprite = Sprite2D.new()
    display_sprite.name = "ReviewedFullResolutionFrame"
    display_sprite.centered = false
    display_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(display_sprite)
    status_label = Label.new()
    status_label.name = "ReviewStatus"
    status_label.position = Vector2(20, 30)
    status_label.add_theme_font_size_override("font_size", 28)
    add_child(status_label)
    var file_path: String = "res://assets/shots/%s/shot.json" % shot_id
    if not FileAccess.file_exists(file_path):
        _fail("SHOT MANIFEST MISSING: " + shot_id)
        return
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(file_path))
    if not parsed is Dictionary:
        _fail("SHOT MANIFEST INVALID")
        return
    manifest = parsed
    if not _approved():
        _fail("SHOT BLOCKED: no approved frame art and motion reviews")
        return
    if autoplay_approved:
        play_if_approved()
    else:
        status_label.text = "ART APPROVED — use play_if_approved() to review"

func _approved() -> bool:
    if manifest.get("approved_for_playback", false) != true:
        return false
    var count: int = int(manifest.get("frame_count", 0))
    if count < 1 or count > 10000:
        return false
    var a: Dictionary = manifest.get("reviewer_signoffs", {})
    for key in ["character_model", "hands", "face", "motion", "environment", "source_rights"]:
        if a.get(key, false) != true:
            return false
    for i in range(count):
        if not ResourceLoader.exists(_frame_path(i)):
            return false
    return true

func _frame_path(index: int) -> String:
    return "res://assets/shots/%s/frames/%04d.png" % [shot_id, index]

func _fail(message: String) -> void:
    playing = false
    if show_review_status:
        status_label.text = message
        push_warning(message)

func _frame_texture(index: int) -> Texture2D:
    if cache.has(index):
        return cache[index] as Texture2D
    var path: String = _frame_path(index)
    if not ResourceLoader.exists(path):
        return null
    var texture: Texture2D = load(path) as Texture2D
    if texture == null:
        return null
    cache[index] = texture
    cache_order.append(index)
    if cache_order.size() > CACHE_LIMIT:
        var oldest: int = cache_order.pop_front()
        cache.erase(oldest)
    return texture

func _show_frame(index: int) -> bool:
    var texture: Texture2D = _frame_texture(index)
    if texture == null:
        _fail("MISSING DRAWING: %04d" % index)
        return false
    var dims: Array = manifest.get("frame_dimensions", [])
    if dims.size() != 2 or texture.get_width() != int(dims[0]) or texture.get_height() != int(dims[1]):
        _fail("WRONG DRAWING DIMENSIONS: %04d" % index)
        return false
    display_sprite.texture = texture
    display_sprite.position = Vector2.ZERO
    display_sprite.scale = Vector2.ONE
    display_sprite.rotation = 0.0
    current_frame = index
    if show_review_status:
        status_label.text = "APPROVED DRAWINGS | frame %04d / %04d" % [index, int(manifest.get("frame_count", 1))-1]
    return true

func play_if_approved() -> bool:
    if not _approved():
        _fail("SHOT BLOCKED — cannot play unapproved art")
        return false
    elapsed = 0.0
    playing = _show_frame(0)
    return playing

func _process(delta: float) -> void:
    if not playing:
        return
    elapsed += delta
    var frame: int = int(floor(elapsed * float(manifest.get("frames_per_second", 24))))
    if frame >= int(manifest.get("frame_count", 0)):
        playing = false
        return
    if frame != current_frame:
        _show_frame(frame)
