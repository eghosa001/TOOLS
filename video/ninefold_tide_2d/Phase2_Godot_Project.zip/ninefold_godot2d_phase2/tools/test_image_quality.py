#!/usr/bin/env python3
from pathlib import Path
from tempfile import TemporaryDirectory
from PIL import Image
from qa_assets import image_issues
with TemporaryDirectory() as d:
    path=Path(d)/'test.png'
    assert image_issues(path,'part')[0].startswith('missing:')
    Image.new('RGB',(64,64),'white').save(path)
    issues=image_issues(path,'part')
    assert any('needs_alpha' in s for s in issues), issues
    Image.new('RGBA',(32,32),(255,0,0,0)).save(path)
    issues=image_issues(path,'part')
    assert any('undersized' in s for s in issues), issues
    assert any('bad_alpha_coverage' in s for s in issues), issues
    im=Image.new('RGBA',(320,320),(0,0,0,0))
    for x in range(80,240):
        for y in range(70,240): im.putpixel((x,y),(20,30,40,255))
    im.save(path)
    assert image_issues(path,'expression')==[]
    Image.new('RGB',(720,400),'white').save(path)
    assert any('undersized' in s for s in image_issues(path,'background'))
print('PASS: image format, transparency, minimum dimensions and incompleteness checks')
