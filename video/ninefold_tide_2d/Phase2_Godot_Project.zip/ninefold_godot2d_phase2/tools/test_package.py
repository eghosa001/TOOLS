#!/usr/bin/env python3
"""Structural checks of the Godot-first studio package; does not waive art approval."""
from qa_assets import ROOT,check
c,w,problems,rows=check()
assert len(c['characters'])==20
assert len(w['locations'])==15
assert len({x['id'] for x in c['characters']})==20
assert len({x['id'] for x in w['locations']})==15
assert set(x['name'] for x in c['characters']) >= {'Naya Venn','Mari','Supervisor Ren'}
for x in c['characters']:
  assert (ROOT/'scenes/characters'/f"{x['id']}.tscn").is_file()
for x in w['locations']:
  assert (ROOT/'scenes/world'/f"{x['id']}.tscn").is_file()
assert len(problems)==35, 'A source claim or artwork approval changed; inspect QA before using it.'
print('Structural test PASS: 20 character rig sockets and 15 environment scene sockets exist. Art production gate deliberately remains BLOCKED.')

# Regression: the hand replacer and artwork manifests must agree on both sides.
for x in c['characters']:
    j=__import__('json').loads((ROOT/'assets/characters'/x['id']/'art_checklist.json').read_text())
    assert len(j['hand_files'])==8
    for side in ('left','right'):
        for pose in ('open','relaxed','grip','point'):
            assert f'hands/{side}_{pose}.png' in j['hand_files']
assert 'is_ready_for_production' in (ROOT/'scripts/character_actor.gd').read_text()
assert 'source_evidence' in (ROOT/'scripts/world_set.gd').read_text()
print('PASS: hand naming, approvals, and original-art evidence checked.')
