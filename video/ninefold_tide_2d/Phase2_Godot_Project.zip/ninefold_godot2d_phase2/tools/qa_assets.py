#!/usr/bin/env python3
"""Reject incomplete/low-fidelity assets. Does not substitute for artistic inspection."""
import argparse, csv, hashlib, json, pathlib, sys
from PIL import Image, UnidentifiedImageError
ROOT = pathlib.Path(__file__).resolve().parents[1]
CORE_APPROVALS = ['art','turnaround','performance','animation','rights']
EVIDENCE_FIELDS = ['source_file','source_sha256','origin','licence_or_ownership','reviewer','review_date',
                   'age_and_canon_checked','one_to_one_design_fidelity','no_sheet_crop_enlargement',
                   'cross_view_consistency','joint_overlap_reviewed']


def image_issues(filename, category):
    """Inspect actual image bytes. Avoid trusting file extensions or generated metadata."""
    p = pathlib.Path(filename)
    if not p.is_file(): return ['missing:'+str(p.name)]
    if p.suffix.lower() != '.png': return ['not_png:'+str(p.name)]
    try:
        with Image.open(p) as im:
            if im.format != 'PNG': return ['not_actual_png:'+str(p.name)]
            width, height = im.size
            if category == 'view':
                min_w, min_h = 700, 1100
            elif category == 'part':
                min_w, min_h = 40, 40
            elif category == 'expression':
                min_w, min_h = 256, 256
            elif category == 'hand':
                min_w, min_h = 96, 96
            else:
                min_w, min_h = 1920, 1080
            errors=[]
            if width < min_w or height < min_h:
                errors.append(f'undersized:{p.name}:{width}x{height}<{min_w}x{min_h}')
            if category in ('part','expression','hand'):
                if im.mode not in ('RGBA','LA','P') or ('A' not in im.getbands() and 'transparency' not in im.info):
                    errors.append('needs_alpha:'+p.name)
                else:
                    alpha=im.convert('RGBA').getchannel('A')
                    lo,hi=alpha.getextrema()
                    if lo == 255 or hi == 0: errors.append('bad_alpha_coverage:'+p.name)
            elif category=='background' and im.mode not in ('RGB','RGBA','P'):
                errors.append('unexpected_color_mode:'+p.name)
            return errors
    except (OSError, UnidentifiedImageError, ValueError) as exc:
        return ['unreadable_image:'+p.name+':'+type(exc).__name__]


def check(root=ROOT, write_status=True):
    c=json.loads((root/'data/cast.json').read_text(encoding='utf-8'))
    w=json.loads((root/'data/world.json').read_text(encoding='utf-8'))
    issues=[]; rows=[]
    for entry in c['characters']:
        cid=entry['id']; base=root/'assets/characters'/cid
        checklist=json.loads((base/'art_checklist.json').read_text(encoding='utf-8'))
        rig=json.loads((base/'rig_calibration.json').read_text(encoding='utf-8'))
        errors=[]
        filesets={'view_files':'view','part_files':'part','expression_files':'expression','hand_files':'hand'}
        for field,typ in filesets.items():
            for rel in checklist.get(field,[]): errors.extend(image_issues(base/rel,typ))
        if len(checklist.get('view_files',[])) != 5: errors.append('five_views_required')
        if len(checklist.get('expression_files',[])) < 8: errors.append('eight_expressions_required')
        if len(checklist.get('hand_files',[])) < 8: errors.append('bilateral_hand_variants_required')
        allparts=[p['part'] for p in c['rig_part_order']]
        for key in allparts:
            for field in ('part_pivots','part_offsets'):
                v=rig.get(field,{}).get(key)
                if not isinstance(v,list) or len(v)!=2 or not all(isinstance(n,(int,float)) and -10000<n<10000 for n in v):
                    errors.append('uncalibrated:'+field+':'+key)
        for name in CORE_APPROVALS:
            if checklist.get('approvals',{}).get(name) is not True: errors.append('approval_required:'+name)
        proof=checklist.get('art_source_evidence',{})
        for field in EVIDENCE_FIELDS:
            if not proof.get(field): errors.append('evidence_required:'+field)
        if rig.get('approved') is not True: errors.append('rig_approval_required')
        existing_views=[base/path for path in checklist.get('view_files',[]) if (base/path).is_file()]
        if len(existing_views)==5:
            hashes=[hashlib.sha256(path.read_bytes()).hexdigest() for path in existing_views]
            if len(set(hashes))!=5: errors.append('duplicated_turnaround_views')
        if errors: issues.append(('character',cid,errors))
        rows.append(dict(kind='character',name=entry['name'],status='BLOCKED' if errors else 'READY',
                         missing_or_invalid_checks=len(errors),notes='No final individual drawings or completed rig' if errors else 'QA passed; artistic review still required'))
    for entry in w['locations']:
        wid=entry['id']; base=root/'assets/world'/wid
        checkdata=json.loads((base/'art_checklist.json').read_text(encoding='utf-8'))
        errors=[]
        for plate in checkdata['plates']:
            errors.extend(image_issues(base/plate,'background'))
            p=base/plate
            if p.exists() and plate not in ('sky.png','far_distance.png'):
                with Image.open(p) as im:
                    rgba=im.convert('RGBA'); lo,hi=rgba.getchannel('A').getextrema()
                    if lo==255: errors.append('background_has_no_transparent_edges:'+plate)
        for key,v in checkdata.get('approval',{}).items():
            if v is not True:errors.append('approval_required:'+key)
        evidence=checkdata.get('source_evidence',{})
        for field in ('source_file','source_sha256','reviewer','licence_or_ownership','continuity_passed'):
            if not evidence.get(field): errors.append('world_evidence_required:'+field)
        if errors: issues.append(('world',wid,errors))
        rows.append(dict(kind='world',name=entry['name'],status='BLOCKED' if errors else 'READY',
                         missing_or_invalid_checks=len(errors),notes='Five fully painted 2D layers still required' if errors else 'QA passed; artistic review still required'))
    if write_status:
        with (root/'QA_STATUS.csv').open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    return c,w,issues,rows


if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--strict',action='store_true'); args=parser.parse_args()
    c,w,issues,_=check()
    print(f"Characters: {len(c['characters'])}; locations: {len(w['locations'])}; blocked: {len(issues)}")
    for typ,name,errors in issues:
        print(f"BLOCKED {typ} {name}: {len(errors)} issues (first: {', '.join(errors[:2])})")
    if args.strict and issues: sys.exit(1)
