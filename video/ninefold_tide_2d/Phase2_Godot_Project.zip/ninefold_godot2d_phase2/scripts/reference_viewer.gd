extends Node2D
## Native-pixel fidelity inspection only. A concept sheet is NOT a puppet.
## Never auto-cut, scale up, or animate this painting.
const REFERENCE: String = "res://assets/characters/naya_venn/reference/naya_style_candidate_20261031.png"

func _ready() -> void:
    var texture: Texture2D = load(REFERENCE) as Texture2D
    if texture == null:
        push_error("Missing original illustration reference")
        return
    var art: Sprite2D = Sprite2D.new()
    art.name = "OriginalArtAt100Percent"
    art.centered = false
    art.position = Vector2(16, 18)
    art.scale = Vector2.ONE
    art.texture = texture
    art.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
    add_child(art)
    var panel: Label = Label.new()
    panel.name = "ReferenceStatus"
    panel.position = Vector2(1575, 32)
    panel.size = Vector2(325, 700)
    panel.add_theme_font_size_override("font_size", 22)
    panel.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    panel.text = "ORIGINAL 2D DESIGN REFERENCE\nNative scale: 100%\n\nNot a rig.\nNot a transparent cut-out pack.\nNot approved moving artwork.\n\nRepaint full-resolution separated parts before production."
    add_child(panel)
