extends Control

func _ready() -> void:
    var characters: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/cast.json"))
    var world: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/world.json"))
    var count: int = 0
    var places: int = 0
    if characters is Dictionary:
        count = (characters.get("characters", []) as Array).size()
    if world is Dictionary:
        places = (world.get("locations", []) as Array).size()
    var label: Label = get_node("Text") as Label
    label.add_theme_font_size_override("font_size", 30)
    label.text = "THE NINEFOLD TIDE — 2D ART ASSET PRODUCTION\n\n" + str(count) + " characters registered | " + str(places) + " world sets registered\n\n" + "STATUS: NOT READY FOR ANIMATION EXPORT\n\n" + "Production source and model slots exist, but independently approved painted layers, turnarounds, facial libraries, rig pivots and scenic planes must be supplied.\n\n" + "Run: python tools/qa_assets.py --strict\n\n" + "Any missing or unapproved model MUST block animation production."
