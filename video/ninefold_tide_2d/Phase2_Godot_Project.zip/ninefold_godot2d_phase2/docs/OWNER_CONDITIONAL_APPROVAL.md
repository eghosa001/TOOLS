# Owner's approval policy — 31 October 2026

The owner has delegated **design-level approval** for high-quality character artwork that fits the visual canon, character descriptions, ages, body proportions and costume states. This removes the need to ask for approval on every aesthetically suitable concept, but it does **not** authorize falsely marking incomplete models or rig art as finished.

## Automatic admission rules

- A candidate may enter the **DESIGN REFERENCE** pool after actual full-resolution visual inspection, canonical names, ages, costume and identifying features check, and originality/rights review.
- Its concept sheet is NOT a 2D rig. Full-body animation drawings must be standalone, drawn at the target resolution; separated layers must be painted in the hidden-overlap areas. No enlarged 250px cutouts.
- Never approve generated sheet captions or group names without checking them against the complete 20-character Drive Bible. A newly generated concept board with invented names/ages has been rejected and excluded.
- Automatically reject images containing unsupported magical motifs, incorrect clothing or age, inconsistent faces or anatomical artifacts, lifted/raising drawbridge geometry in place of the canonical tide-rotating roadways, or unlicensed source imagery.
- Godot stays 2D-only. Its runtime can manipulate approved layers and replacement keys, but cannot turn a single painting into hand-drawn animation quality.
- Separate approvals for independent views, transparent part kit, left/right hands, emotional acting, camera stage and environment continuity are still required. The strict QA test fails until those exist.

## Production status

Naya's high-resolution illustrative style sheet is available as a **candidate** under `assets/characters/naya_venn/reference/`. Its quality is notably above older vector experiments, but not proof of a completed five-view model or acting/rig cutout layers. Do not regenerate a lower-quality flat vector figure to fill these gaps.
