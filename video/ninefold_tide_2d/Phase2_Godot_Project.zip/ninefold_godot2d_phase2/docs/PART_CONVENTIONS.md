# Minimal 2D cut-out artwork convention

Maintain one authoritative 1:1 source artwork file for each view; save native Krita/ORA/PSD and lossless PNG layers. For all 20 cast members use original per-character wardrobe; do not blindly reuse the same generic body rig art.

* `views/front.png`, `views/front_three_quarter.png`, `views/profile.png`, `views/rear_three_quarter.png`, `views/rear.png`: full height original independent model drawings, source at least 700×1100 pixels (better 1200×2000+).
* `parts/*.png`: artist-painted RGBA cutouts with complete art *under* joints; minimum 40×40 px, real transparent boundary.
* `hands/left_open.png`, `hands/right_open.png` etc: both sides for open, relaxed, grip and point. No mirrored scars or mismatched gloves.
* `expressions/*.png`: head-aligned full-face replacement drawings, at least 256×256 px, no independent AI face swap drifting facial landmarks.
* `rig_calibration.json`: **local relative** 2D pivot and layer offset coordinates in pixels, separately set for each character. Null values mean not rigged.
* Source data and QA: SHA-256 of the native drawing source, ownership/licence, reviewer, all five views comparable and 100% native pixel visual check.

### Engine quality rules

Use `Sprite2D` source textures without upscaling. Set interpolation to linear at 1:1 for painted art; only use nearest when actually designing pixel art. Never auto-shear one full-body 2D image to simulate a new camera angle. Replacement drawings required for significant head turns, reach and grip contact. Keep foreground rail painted separately so it occludes the correct hand and torso surfaces.

Keep facial source overlays aligned to the `head` joint. Godot hides the base eyes/brows/mouth when the artist-supplied full-expression overlay is displayed; without proper alignment this will still fail picture QA. No experimental pass may bypass strict QA or be labelled production-ready.
