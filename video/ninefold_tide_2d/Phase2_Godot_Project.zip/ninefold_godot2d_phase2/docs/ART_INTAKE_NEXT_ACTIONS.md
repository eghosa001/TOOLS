# Art intake after owner's conditional design approval

The owner accepts any character **design** that is demonstrably high-quality and consistent with the canonical character age, description and style. This is NOT approval of fabricated rig parts or a licence to skip technical, continuity or visual QA.

## First review

Naya concept image in `assets/characters/naya_venn/reference/` is retained as style reference. It is an original high-quality illustration, but the five miniature full-body views embedded in one sheet are **not** acceptable 1080p animation cutouts. Do not crop-and-enlarge them to fill an animation scene. The scar must be checked on the **anatomical left** rather than the viewer's left. Don't treat the image's printed labels as canonical facts.

## Next actions, in order

1. Artist creates one standalone 1080p-or-larger Naya full-body frontal drawing from the accepted design, with detached layers **redrawn at full resolution** (including hidden material under elbows/knees) rather than crops. Preserve source ORA/KRA/PSD and source checksum.
2. Produce independent profile and 3/4 views, plus rear angles. Approve cross-view identity and *age*.
3. Paint transparent body parts, 8 complete face replacements, 8 hand replacements (left/right x 4), eyebrow and mouth variants. Check the full scene at 100%.
4. Set accurate part pivots/offsets, then import source PNGs into the existing Godot scenes. Godot movements must be small; structural turns and complicated hand contacts use drawn replacement poses.
5. In parallel, build independently painted service gallery world plates (sky, far, middle, ground, foreground rail). One composite plate or raised drawbridge painting is **not** a completed five-layer setting. Veyra uses tide-powered, pivoting causeways, not generic drawbridge geometry.
6. Run image quality test and strict gate. It must fail until every named approval and actual art is present; then review appearance at 100% before motion.

Other characters repeat this process; do not batch-approve from a stylized crowd sheet. No new animation video before all user-required production assets satisfy the gate.

No paid video credits, Blender, 3D environment or extra AI video model is required.
