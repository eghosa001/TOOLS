# Non-negotiable art acceptance standard

This project does not treat a technically moving puppet as finished animation. All characters and sets need separately reviewed final-art sources, not cropped previews.

**Character, 20 each:** independently drawn five-angle model sheet, silhouette consistency, face landmarks and hair geometry, age-correct proportions, seven or more facial visemes and eight distinct acting emotions, hand and prop grips, transparent cutout PNGs with under-joint painted overlap, clean consistent costume seams, independent neck/head/arms/hands/legs, hand-drawn 3/4 and profile acting replacements, calibrated pivots, native-resolution 1080p scene inspection and reference comparisons, resolved costume and injury continuity. At least one natural acting exercise before character status may be approved.

**World, 15 sets:** independent 1920x1080 painterly 2D `sky/far_distance/middle_distance/playable_floor/foreground_occlusion` plates plus variant weather/time when required, fixed architectural landmarks, lighting and occlusion consistency, bridge/cable/rope physical layout. Drawn backgrounds are not converted from 3D greyboxes.

**Failure cases:** cropping individual figures from a low-resolution board then enlarging; using auto-morphing for genuine head turn; forgetting left/right scars or injuries; warped hand fingers; changing costume between front and profile; backgrounds cut from concept boards with text labels; creating a heavy ferry mooring from Kito's messenger spool; moving the fixed ferry quay between shots; using generic unlicensed audio/character lookalikes.

**Review:** Source file and licence -> 100% size inspection -> cross-view likeness -> pose/occlusion inspection -> expressive movement on phone -> specific named reviewer sign-off -> only then enable export in a future production workflow.
