extends SceneTree

func _initialize() -> void:
    call_deferred("_run")

func fail(message: String, code: int) -> void:
    push_error(message)
    quit(code)

func _run() -> void:
    var packed: PackedScene = load("res://scenes/tests/qa_mock_actor_motion_review.tscn")
    if packed == null:
        fail("QA mock rig scene missing", 2)
        return
    var scene: Node2D = packed.instantiate()
    get_root().add_child(scene)
    await process_frame
    var actor: Node2D = scene.get_node("Actor") as Node2D
    if actor == null or not actor.has_method("reset_to_rest") or not actor.can_motion_review():
        fail("Mock actor failed approved art intake", 3)
        return
    actor.reset_to_rest()
    var coords: Dictionary = actor.calibration.get("part_pivots", {})
    for key in coords.keys():
        var desired: Variant = coords[key]
        if not desired is Array or desired.size() != 2:
            fail("Bad pivot data: " + str(key), 4)
            return
        var part: Node2D = actor.joints.get(key) as Node2D
        if part == null:
            fail("Missing joint: " + str(key), 5)
            return
        var actual: Vector2 = part.global_position - actor.global_position
        var expected := Vector2(float(desired[0]), float(desired[1]))
        if actual.distance_to(expected) > 0.03:
            fail("Incorrect rest world pivot on %s: %s != %s" % [key, actual, expected], 6)
            return
    var review: Node2D = scene
    if not review.seek_frame(12):
        fail("Could not seek approved frame 12", 7)
        return
    var rotation12: float = (actor.joints["head"] as Node2D).rotation_degrees
    if absf(rotation12) < 1.0:
        fail("Head did not turn at frame 12", 8)
        return
    if not review.seek_frame(24):
        fail("Could not seek approved frame 24", 9)
        return
    var rotation24: float = (actor.joints["left_upper_arm"] as Node2D).rotation_degrees
    if absf(rotation24) < 15.0:
        fail("Arm did not move at frame 24", 10)
        return
    var expression: String = actor.active_expression
    if expression != "determined":
        fail("Expression not switched with keyframe", 11)
        return
    if actor.apply_pose_dict({}, false):
        fail("Rig permitted unclamped animation", 12)
        return
    for part_name in actor.joints.keys():
        if part_name == "root":
            continue
        var joint: Node2D = actor.joints[part_name] as Node2D
        if joint.scale != Vector2.ONE:
            fail("Joint scaled/deformed: " + part_name, 13)
            return
        var sprite: Sprite2D = joint.get_node_or_null("Art") as Sprite2D
        if sprite != null and sprite.scale != Vector2.ONE:
            fail("Source art rescaled: " + part_name, 14)
            return
    if not review.seek_frame(47):
        fail("Failed final reviewed frame", 15)
        return
    if actor.active_expression != "relieved":
        fail("Final expression was not correct", 16)
        return
    var not_ready: PackedScene = load("res://scenes/characters/kito_vale.tscn")
    if not_ready == null:
        fail("Unapproved actor scene missing", 17)
        return
    var blocked_actor: Node2D = not_ready.instantiate()
    get_root().add_child(blocked_actor)
    if blocked_actor.can_motion_review() or blocked_actor.is_ready_for_production():
        fail("Unapproved real-cast artwork incorrectly passed", 18)
        return
    print("PASS: 25 canvas pivots match real rest positions, rig moved at keyframes, no warping, unapproved cast blocked")
    quit(0)
