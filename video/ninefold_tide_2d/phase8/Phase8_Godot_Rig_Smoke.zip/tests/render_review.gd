extends SceneTree

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var viewport := SubViewport.new()
    viewport.size = Vector2i(640, 960)
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    viewport.transparent_bg = true
    get_root().add_child(viewport)
    var scene: PackedScene = load("res://scenes/tests/qa_mock_actor_motion_review.tscn")
    if scene == null:
        push_error("Scene did not load")
        quit(2)
        return
    var instance: Node2D = scene.instantiate()
    viewport.add_child(instance)
    instance.set_process(false)
    var actor: Node2D = instance.get_node("Actor") as Node2D
    if actor == null or not actor.can_motion_review():
        push_error("Mock motion rig unexpectedly blocked")
        quit(3)
        return
    var frames := [0, 12, 24, 47]
    var paths: Array[String] = []
    for frame in frames:
        if not instance.seek_frame(frame):
            push_error("Cannot seek: " + str(frame))
            quit(4)
            return
        for i in range(3):
            await process_frame
        await RenderingServer.frame_post_draw
        var image: Image = viewport.get_texture().get_image()
        if image == null or image.is_empty():
            push_error("Rendered image empty")
            quit(5)
            return
        var path := "res://review_frame_%02d.png" % frame
        var error: Error = image.save_png(path)
        if error != OK:
            push_error("Could not write frame image: " + str(error))
            quit(6)
            return
        paths.append(path)
    print("PASS 4 genuine Godot render snapshots: ", paths)
    quit(0)
