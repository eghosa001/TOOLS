extends Node2D
## Drives a quality-preserving hybrid 2D motion review.
## It interpolates only rotation/translation values between reviewed poses,
## keeping artwork at native scale and using explicit hand/expression swaps.
@export var actor_path: NodePath = NodePath("Actor")
@export var clip_path: String = ""
@export var autoplay: bool = true
@export var show_status: bool = true

var actor: Node2D
var status_label: Label
var clip: Dictionary = {}
var library: Dictionary = {}
var keyframes: Array = []
var playing: bool = false
var elapsed: float = 0.0
var current_frame: int = 0
var completed: bool = false

func _ready() -> void:
    actor = get_node_or_null(actor_path) as Node2D
    status_label = Label.new()
    status_label.position = Vector2(20, 20)
    status_label.add_theme_font_size_override("font_size", 22)
    add_child(status_label)
    if actor == null:
        _block("MISSING ACTOR")
        return
    if clip_path.is_empty() or not FileAccess.file_exists(clip_path):
        _block("MISSING MOTION CLIP")
        return
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(clip_path))
    if not parsed is Dictionary:
        _block("INVALID MOTION CLIP")
        return
    clip = parsed
    if not actor.has_method("load_pose_library"):
        _block("ACTOR SCRIPT UNSUPPORTED")
        return
    library = actor.load_pose_library()
    keyframes = clip.get("keyframes", [])
    if int(clip.get("frames_per_second", 0)) <= 0 or int(clip.get("length_frames", 0)) <= 0:
        _block("INVALID FRAME RATE OR LENGTH")
        return
    var prior := -1
    for keyframe in keyframes:
        if not keyframe is Dictionary or int(keyframe.get("frame", -1)) <= prior:
            _block("UNSORTED OR INVALID KEYFRAMES")
            return
        prior = int(keyframe.get("frame", -1))
    if not keyframes.is_empty() and prior >= int(clip.get("length_frames", 0)):
        _block("KEYFRAME EXCEEDS CLIP LENGTH")
        return
    if not bool(clip.get("approved_for_motion_review", false)):
        _block("CLIP NOT APPROVED")
        return
    if keyframes.size() < 2:
        _block("INSUFFICIENT KEYFRAMES")
        return
    if not actor.can_motion_review():
        _block("ACTOR NOT APPROVED FOR MOTION")
        return
    if autoplay:
        play()
    else:
        status_label.text = "READY FOR MOTION REVIEW"

func play() -> void:
    elapsed = 0.0
    current_frame = 0
    completed = false
    playing = true
    seek_frame(0)

func _block(message: String) -> void:
    playing = false
    completed = false
    if show_status:
        status_label.text = message
    push_warning(message)

func _process(delta: float) -> void:
    if not playing:
        return
    elapsed += delta
    var fps: float = float(clip.get("frames_per_second", 24))
    current_frame = int(floor(elapsed * fps))
    var total_frames: int = int(clip.get("length_frames", 0))
    if current_frame >= total_frames:
        current_frame = total_frames - 1
        seek_frame(current_frame)
        playing = false
        completed = true
        if show_status:
            status_label.text = "MOTION REVIEW COMPLETE"
        return
    seek_frame(current_frame)

func _find_segment(frame: int) -> Array:
    var previous: Dictionary = keyframes[0] as Dictionary
    var upcoming: Dictionary = keyframes[keyframes.size() - 1] as Dictionary
    for i in range(keyframes.size() - 1):
        var a: Dictionary = keyframes[i]
        var b: Dictionary = keyframes[i + 1]
        if frame >= int(a.get("frame", 0)) and frame <= int(b.get("frame", 0)):
            previous = a
            upcoming = b
            break
    return [previous, upcoming]

func _pose_named(name: String) -> Dictionary:
    var poses: Dictionary = library.get("poses", {})
    return poses.get(name, {}) if poses.has(name) else {}

func _lerp_float(a: float, b: float, t: float) -> float:
    return a + (b - a) * t

func _merge_part_state(a: Dictionary, b: Dictionary, t: float) -> Dictionary:
    var out: Dictionary = {}
    out["rotation_degrees"] = _lerp_float(float(a.get("rotation_degrees", 0.0)), float(b.get("rotation_degrees", 0.0)), t)
    var ao: Variant = a.get("offset", [0.0, 0.0])
    var bo: Variant = b.get("offset", [0.0, 0.0])
    var av := Vector2.ZERO
    var bv := Vector2.ZERO
    if ao is Array and ao.size() == 2:
        av = Vector2(float(ao[0]), float(ao[1]))
    if bo is Array and bo.size() == 2:
        bv = Vector2(float(bo[0]), float(bo[1]))
    var ov := av.lerp(bv, t)
    out["offset"] = [ov.x, ov.y]
    out["visible"] = bool(b.get("visible", a.get("visible", true)))
    return out

func _interpolate_pose(pose_a: Dictionary, pose_b: Dictionary, t: float, segment_a: Dictionary, segment_b: Dictionary) -> Dictionary:
    var out: Dictionary = {"parts": {}}
    var parts_a: Dictionary = pose_a.get("parts", {})
    var parts_b: Dictionary = pose_b.get("parts", {})
    var keys: Dictionary = {}
    for key in parts_a.keys():
        keys[key] = true
    for key in parts_b.keys():
        keys[key] = true
    for key in keys.keys():
        var state_a: Dictionary = parts_a.get(key, {})
        var state_b: Dictionary = parts_b.get(key, state_a)
        out["parts"][key] = _merge_part_state(state_a, state_b, t)
    var expr: String = str(segment_a.get("expression", ""))
    if current_frame >= int(segment_b.get("frame", 0)):
        expr = str(segment_b.get("expression", expr))
    out["expression"] = expr
    out["hands"] = {}
    for side in ["left", "right"]:
        var start_hands: Dictionary = segment_a.get("hands", {})
        var end_hands: Dictionary = segment_b.get("hands", {})
        out["hands"][side] = str(start_hands.get(side, end_hands.get(side, "open")))
        if current_frame >= int(segment_b.get("frame", 0)):
            out["hands"][side] = str(end_hands.get(side, out["hands"][side]))
    return out

func frame_progress_t(a: Dictionary, b: Dictionary) -> float:
    var fa: int = int(a.get("frame", 0))
    var fb: int = int(b.get("frame", fa + 1))
    if fb <= fa:
        return 0.0
    return clampf(float(current_frame - fa) / float(fb - fa), 0.0, 1.0)

func seek_frame(frame: int) -> bool:
    # Frame-exact seeking is essential for deterministic QA and editorial review.
    if keyframes.is_empty() or actor == null:
        return false
    var last: int = int(clip.get("length_frames", 0)) - 1
    if frame < 0 or frame > last:
        return false
    current_frame = frame
    var segment: Array = _find_segment(frame)
    var a: Dictionary = segment[0]
    var b: Dictionary = segment[1]
    var t: float = frame_progress_t(a, b)
    var interp: String = str(a.get("interpolation", "smooth"))
    if interp == "hold":
        t = 1.0 if frame >= int(b.get("frame", 0)) else 0.0
    elif interp == "smooth":
        t = t * t * (3.0 - 2.0 * t)
    elif interp != "linear":
        _block("UNSUPPORTED INTERPOLATION")
        return false
    var pose_a: Dictionary = _pose_named(str(a.get("pose", "")))
    var pose_b: Dictionary = _pose_named(str(b.get("pose", str(a.get("pose", "")))))
    if pose_a.is_empty() or pose_b.is_empty():
        _block("UNREVIEWED POSE IN CLIP")
        return false
    var interpolated: Dictionary = _interpolate_pose(pose_a, pose_b, t, a, b)
    if not bool(actor.apply_pose_dict(interpolated, true)):
        _block("ACTOR ART NOT READY")
        return false
    if show_status:
        status_label.text = "MOTION FRAME %03d" % frame
    return true
