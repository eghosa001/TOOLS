@tool
extends Node2D
## Quality-preserving 2D character actor.
## Uses approved native-resolution art parts only, rigid transforms only, and clamped rotations/translations.
## Never applies non-uniform scale, mesh deformation or automatic warping.
@export var character_id: String = "naya_venn"
@export var show_missing_warnings: bool = true

const PARTS: Array[String] = ["back_hair", "back_cape", "rear_accessory",
    "left_thigh", "left_calf", "left_foot", "right_thigh", "right_calf", "right_foot",
    "pelvis", "torso", "neck", "head", "left_upper_arm", "left_forearm", "left_hand",
    "right_upper_arm", "right_forearm", "right_hand", "eyes", "brows", "mouth",
    "front_hair", "front_costume", "front_accessory"]
const PARENTS: Dictionary = {
    "left_calf":"left_thigh", "left_foot":"left_calf",
    "right_calf":"right_thigh", "right_foot":"right_calf",
    "torso":"pelvis", "neck":"torso", "head":"neck",
    "left_upper_arm":"torso", "left_forearm":"left_upper_arm", "left_hand":"left_forearm",
    "right_upper_arm":"torso", "right_forearm":"right_upper_arm", "right_hand":"right_forearm",
    "eyes":"head", "brows":"head", "mouth":"head", "front_hair":"head",
    "front_costume":"torso", "front_accessory":"torso"
}
const DEFAULT_LIMITS: Dictionary = {
    "left_thigh": {"rotation_min": -55.0, "rotation_max": 55.0, "offset_x": 36.0, "offset_y": 32.0},
    "left_calf": {"rotation_min": -10.0, "rotation_max": 115.0, "offset_x": 20.0, "offset_y": 26.0},
    "left_foot": {"rotation_min": -45.0, "rotation_max": 35.0, "offset_x": 18.0, "offset_y": 12.0},
    "right_thigh": {"rotation_min": -55.0, "rotation_max": 55.0, "offset_x": 36.0, "offset_y": 32.0},
    "right_calf": {"rotation_min": -10.0, "rotation_max": 115.0, "offset_x": 20.0, "offset_y": 26.0},
    "right_foot": {"rotation_min": -35.0, "rotation_max": 45.0, "offset_x": 18.0, "offset_y": 12.0},
    "pelvis": {"rotation_min": -14.0, "rotation_max": 14.0, "offset_x": 18.0, "offset_y": 20.0},
    "torso": {"rotation_min": -22.0, "rotation_max": 22.0, "offset_x": 20.0, "offset_y": 24.0},
    "neck": {"rotation_min": -16.0, "rotation_max": 16.0, "offset_x": 8.0, "offset_y": 10.0},
    "head": {"rotation_min": -32.0, "rotation_max": 32.0, "offset_x": 14.0, "offset_y": 14.0},
    "left_upper_arm": {"rotation_min": -130.0, "rotation_max": 130.0, "offset_x": 22.0, "offset_y": 22.0},
    "left_forearm": {"rotation_min": -160.0, "rotation_max": 160.0, "offset_x": 18.0, "offset_y": 18.0},
    "left_hand": {"rotation_min": -45.0, "rotation_max": 45.0, "offset_x": 8.0, "offset_y": 8.0},
    "right_upper_arm": {"rotation_min": -130.0, "rotation_max": 130.0, "offset_x": 22.0, "offset_y": 22.0},
    "right_forearm": {"rotation_min": -160.0, "rotation_max": 160.0, "offset_x": 18.0, "offset_y": 18.0},
    "right_hand": {"rotation_min": -45.0, "rotation_max": 45.0, "offset_x": 8.0, "offset_y": 8.0},
    "eyes": {"rotation_min": 0.0, "rotation_max": 0.0, "offset_x": 6.0, "offset_y": 4.0},
    "brows": {"rotation_min": -8.0, "rotation_max": 8.0, "offset_x": 6.0, "offset_y": 4.0},
    "mouth": {"rotation_min": -6.0, "rotation_max": 6.0, "offset_x": 6.0, "offset_y": 4.0},
    "front_hair": {"rotation_min": -12.0, "rotation_max": 12.0, "offset_x": 10.0, "offset_y": 10.0},
    "front_costume": {"rotation_min": -18.0, "rotation_max": 18.0, "offset_x": 16.0, "offset_y": 16.0},
    "front_accessory": {"rotation_min": -20.0, "rotation_max": 20.0, "offset_x": 12.0, "offset_y": 12.0},
    "back_hair": {"rotation_min": -14.0, "rotation_max": 14.0, "offset_x": 10.0, "offset_y": 12.0},
    "back_cape": {"rotation_min": -18.0, "rotation_max": 18.0, "offset_x": 12.0, "offset_y": 18.0},
    "rear_accessory": {"rotation_min": -20.0, "rotation_max": 20.0, "offset_x": 12.0, "offset_y": 12.0}
}

var joints: Dictionary = {}
var calibration: Dictionary = {}
var missing: PackedStringArray = PackedStringArray()
var base_positions: Dictionary = {}
var base_offsets: Dictionary = {}
var constraints: Dictionary = {}
var active_expression: String = ""
var original_hand_textures: Dictionary = {}
const Z_ORDER: Dictionary = {"back_hair":-20,"back_cape":-19,"rear_accessory":-18,"left_thigh":-10,"left_calf":-9,"left_foot":-8,"right_thigh":-10,"right_calf":-9,"right_foot":-8,"pelvis":-5,"torso":0,"neck":2,"head":5,"left_upper_arm":6,"left_forearm":7,"left_hand":8,"right_upper_arm":6,"right_forearm":7,"right_hand":8,"eyes":9,"brows":9,"mouth":9,"front_hair":11,"front_costume":10,"front_accessory":12}

func _ready() -> void:
    rebuild()

func rebuild() -> void:
    _remove_built_nodes()
    calibration = {}
    constraints = DEFAULT_LIMITS.duplicate(true)
    var path: String = "res://assets/characters/%s/rig_calibration.json" % character_id
    if FileAccess.file_exists(path):
        var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
        if parsed is Dictionary:
            calibration = parsed
    if calibration.has("joint_constraints") and calibration["joint_constraints"] is Dictionary:
        for key in calibration["joint_constraints"].keys():
            constraints[key] = calibration["joint_constraints"][key]
    var pivots: Dictionary = calibration.get("part_pivots", {})
    var offsets: Dictionary = calibration.get("part_offsets", {})
    joints["root"] = self
    for part in PARTS:
        var parent_key: String = str(PARENTS.get(part, "root"))
        var joint: Node2D = Node2D.new()
        joint.name = part
        joint.set_meta("generated_rig_node", true)
        var par: Node2D = joints.get(parent_key, self) as Node2D
        par.add_child(joint)
        joint.z_as_relative = false
        joint.z_index = int(Z_ORDER.get(part, 0))
        joints[part] = joint
        var pivot_data: Variant = pivots.get(part)
        var parent_pivot: Variant = pivots.get(parent_key, [0.0, 0.0])
        var offset_data: Variant = offsets.get(part)
        if pivot_data is Array and pivot_data.size() == 2 and parent_pivot is Array and parent_pivot.size() == 2:
            # Art pivots are absolute in the rest canvas. Nested Node2D positions MUST
            # be parent-relative, otherwise torso/head/arms drift by hundreds of pixels.
            var world_pivot := Vector2(float(pivot_data[0]), float(pivot_data[1]))
            var parent_world_pivot := Vector2(float(parent_pivot[0]), float(parent_pivot[1]))
            joint.position = world_pivot - parent_world_pivot
            base_positions[part] = joint.position
        else:
            missing.append("pivot:" + part)
            base_positions[part] = Vector2.ZERO
        var sprite: Sprite2D = Sprite2D.new()
        sprite.name = "Art"
        sprite.centered = false
        sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
        joint.add_child(sprite)
        if offset_data is Array and offset_data.size() == 2:
            sprite.position = Vector2(float(offset_data[0]), float(offset_data[1]))
            base_offsets[part] = sprite.position
        else:
            missing.append("offset:" + part)
            base_offsets[part] = Vector2.ZERO
        var art_path: String = "res://assets/characters/%s/parts/%s.png" % [character_id, part]
        if ResourceLoader.exists(art_path):
            sprite.texture = load(art_path)
            sprite.scale = Vector2.ONE
            if part == "left_hand" or part == "right_hand":
                original_hand_textures[part] = sprite.texture
        else:
            missing.append("art:" + part)
    if show_missing_warnings and not missing.is_empty():
        push_warning("%s is NOT animation ready; missing %d parts/pivots. See art_checklist.json." % [character_id, missing.size()])

func _remove_built_nodes() -> void:
    for child in get_children():
        if child.has_meta("generated_rig_node"):
            child.free()
    joints.clear()
    missing.clear()
    base_positions.clear()
    base_offsets.clear()
    active_expression = ""
    original_hand_textures.clear()

func _get_limits(part: String) -> Dictionary:
    return constraints.get(part, {"rotation_min": -180.0, "rotation_max": 180.0, "offset_x": 100000.0, "offset_y": 100000.0})

func _clamp_angle(part: String, value: float) -> float:
    var lim: Dictionary = _get_limits(part)
    return clampf(value, float(lim.get("rotation_min", -180.0)), float(lim.get("rotation_max", 180.0)))

func _clamp_offset(part: String, offset: Vector2) -> Vector2:
    var lim: Dictionary = _get_limits(part)
    return Vector2(
        clampf(offset.x, -float(lim.get("offset_x", 100000.0)), float(lim.get("offset_x", 100000.0))),
        clampf(offset.y, -float(lim.get("offset_y", 100000.0)), float(lim.get("offset_y", 100000.0)))
    )

func set_expression(expression_name: String) -> bool:
    var path: String = "res://assets/characters/%s/expressions/%s.png" % [character_id, expression_name]
    if not ResourceLoader.exists(path) or not joints.has("head"):
        return false
    var joint: Node2D = joints["head"] as Node2D
    var face: Sprite2D = joint.get_node_or_null("Expression") as Sprite2D
    if face == null:
        face = Sprite2D.new()
        face.name = "Expression"
        joint.add_child(face)
    face.centered = false
    # A replacement expression is painted in the same local rect as the head art.
    # Using ZERO positions the face at the neck/head pivot instead of on the head.
    face.position = base_offsets.get("head", Vector2.ZERO)
    face.texture = load(path)
    face.visible = true
    face.scale = Vector2.ONE
    face.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    active_expression = expression_name
    for layer_name in ["eyes", "brows", "mouth"]:
        if joints.has(layer_name):
            var base_sprite: Sprite2D = (joints[layer_name] as Node2D).get_node_or_null("Art") as Sprite2D
            if base_sprite != null:
                base_sprite.visible = false
    return true

func restore_expression() -> void:
    active_expression = ""
    if not joints.has("head"):
        return
    var head: Node2D = joints["head"] as Node2D
    var face: Sprite2D = head.get_node_or_null("Expression") as Sprite2D
    if face != null:
        face.visible = false
    for key in ["eyes", "brows", "mouth"]:
        if joints.has(key):
            var base: Sprite2D = (joints[key] as Node2D).get_node_or_null("Art") as Sprite2D
            if base != null:
                base.visible = true

func set_hand(side: String, variant: String) -> bool:
    if side != "left" and side != "right":
        return false
    var path: String = "res://assets/characters/%s/hands/%s_%s.png" % [character_id, side, variant]
    if not ResourceLoader.exists(path):
        return false
    var joint: Node2D = joints.get(side + "_hand") as Node2D
    if joint == null:
        return false
    var sprite: Sprite2D = joint.get_node("Art") as Sprite2D
    sprite.texture = load(path)
    sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    sprite.scale = Vector2.ONE
    return true

func _apply_part_state(part: String, state: Dictionary, clamp_limits: bool = true) -> void:
    if not joints.has(part):
        return
    var joint: Node2D = joints[part] as Node2D
    var angle: float = float(state.get("rotation_degrees", 0.0))
    if clamp_limits:
        angle = _clamp_angle(part, angle)
    joint.rotation_degrees = angle
    var offset := Vector2.ZERO
    var offset_data: Variant = state.get("offset", [0.0,0.0])
    if offset_data is Array and offset_data.size() == 2:
        offset = Vector2(float(offset_data[0]), float(offset_data[1]))
    if clamp_limits:
        offset = _clamp_offset(part, offset)
    joint.position = base_positions.get(part, Vector2.ZERO) + offset
    joint.scale = Vector2.ONE
    var visible_state := state.get("visible", true)
    var art: Sprite2D = joint.get_node_or_null("Art") as Sprite2D
    if art != null:
        art.visible = bool(visible_state)
        art.scale = Vector2.ONE

func reset_to_rest() -> void:
    # Reset state so sequential poses do not accumulate hidden layers or hand swaps.
    restore_expression()
    for side in ["left_hand", "right_hand"]:
        if original_hand_textures.has(side) and joints.has(side):
            var art: Sprite2D = (joints[side] as Node2D).get_node_or_null("Art") as Sprite2D
            if art != null:
                art.texture = original_hand_textures[side]
    for part in PARTS:
        _apply_part_state(part, {}, true)
        if joints.has(part):
            (joints[part] as Node2D).scale = Vector2.ONE

func apply_pose_dict(pose_data: Dictionary, clamp_limits: bool = true) -> bool:
    if not can_motion_review():
        push_warning("Motion blocked: %s lacks fully approved art/calibration." % character_id)
        return false
    # An explicit false used to bypass the physical joint constraints; never allow it.
    if not clamp_limits:
        push_warning("Unclamped joint movement is forbidden in production")
        return false
    reset_to_rest()
    var part_map: Dictionary = pose_data.get("parts", {})
    for part in part_map.keys():
        if part_map[part] is Dictionary:
            _apply_part_state(str(part), part_map[part], clamp_limits)
    if pose_data.has("expression"):
        var expr: String = str(pose_data.get("expression", ""))
        if expr.is_empty():
            restore_expression()
        else:
            set_expression(expr)
    if pose_data.has("hands") and pose_data["hands"] is Dictionary:
        var hands: Dictionary = pose_data["hands"]
        for side in hands.keys():
            set_hand(str(side), str(hands[side]))
    return true

func apply_pose_name(pose_name: String) -> bool:
    var library := load_pose_library()
    if library.is_empty():
        return false
    var poses: Dictionary = library.get("poses", {})
    if not poses.has(pose_name) or not poses[pose_name] is Dictionary:
        return false
    return apply_pose_dict(poses[pose_name] as Dictionary)

func load_pose_library() -> Dictionary:
    var path := "res://assets/characters/%s/pose_library.json" % character_id
    if not FileAccess.file_exists(path):
        return {}
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
    if parsed is Dictionary:
        return parsed as Dictionary
    return {}

func can_motion_review() -> bool:
    var library := load_pose_library()
    if library.is_empty() or library.get("approved_for_motion_review", false) != true:
        return false
    return is_ready_for_production()

func is_ready_for_production() -> bool:
    if not missing.is_empty() or not bool(calibration.get("approved", false)):
        return false
    var checklist_path: String = "res://assets/characters/%s/art_checklist.json" % character_id
    if not FileAccess.file_exists(checklist_path):
        return false
    var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(checklist_path))
    if not parsed is Dictionary:
        return false
    var checklist: Dictionary = parsed
    for category in ["view_files", "part_files", "expression_files", "hand_files"]:
        for file in checklist.get(category, []):
            if not ResourceLoader.exists("res://assets/characters/%s/%s" % [character_id, file]):
                return false
    for value in checklist.get("approvals", {}).values():
        if value != true:
            return false
    var evidence: Dictionary = checklist.get("art_source_evidence", {})
    for key in ["source_file", "source_sha256", "origin", "licence_or_ownership", "reviewer", "review_date", "age_and_canon_checked", "one_to_one_design_fidelity", "no_sheet_crop_enlargement", "cross_view_consistency", "joint_overlap_reviewed"]:
        if not evidence.get(key, false):
            return false
    return true
