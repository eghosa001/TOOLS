# The Ninefold Tide — Godot-only 2D art production (Stage 1)

**No Blender. No 3D. No cloud GPU. No video export.** This package begins the *art-asset readiness* process the owner requested, without lowering the existing illustration quality. All character concept images are **references**, not rig-ready artwork.

## What's actually implemented

- Correct **20-character** register from the Drive Character Bible (19 original plus Supervisor Ren).
- **20 Godot 4 `.tscn` rig sockets**, using one reusable Node2D cut-out hierarchy, optional separately drawn facial expressions and hand replacements, and calibrated part pivots.
- **15 Godot 4 `.tscn` world-set sockets**, including eight public wards, hidden Morrow Reach and six priority scene backgrounds, using 5 flat painted image planes each.
- Per-character production file checklists, calibration records and automated strict QA that **intentionally fails until approved artwork is supplied**.
- No placeholder anatomy, automatic generic face rigs, random vector redraws, hidden 3D assets, or acceptance of a concept-sheet crop as an animated character.

## What is *not* completed (do not misrepresent)

None of the 20 models currently has a complete independently painted transparent RGBA part kit, calibrated joints, approved full turnarounds/expressions/hand libraries and reviewed motion. None of the 15 scene sets has five approved full-resolution separated layers. Godot itself has **not** been run in this environment; structural tests are not playback verification. The source artwork has been kept unaltered in Drive.

## Local validation

```bash
python tools/test_package.py
python tools/qa_assets.py --strict  # expected failure until approval; blocks animation output
```

Open `project.godot` in Godot 4.x. The dashboard explains why animation is blocked. Once artist-approved 2D PNGs are placed in the listed folders and calibration/approval files are completed, the cut-out rig can load art. Complex perspective changes require independently hand-drawn replacement keyframes; do not simply rotate a flat face image through 3D-like turns.

## Production order

1. **Design identity approval** from the existing Drive art: canon descriptions/colour/props, one character at a time. Previously rejected vector approximations are not production models.
2. **Complete Naya art kit**: full-resolution independent five-angle sheets, layered cut-outs with joint overlaps, facial library and hand variants, 2D painted world planes for E101 service-gallery.
3. **Calibrate rig** and preview isolated rotations; prohibit visual deformation, finger inconsistencies and soft enlargements. Get explicit art/animation acceptance.
4. Complete Kito and Iri; then named cast and supporting cast in story-use order. Model sheets are separately reviewed before cut-out work.
5. Finish all required world planes and variations while checking geography and continuity.
6. Only AFTER rig art, environmental art, actor performance, rights and approval gates pass, make a new video.

## Source-of-truth

- [Complete cast and character descriptions](https://docs.google.com/document/d/1TnnN33aXBXqhjNeAPzdwZeduLPOzFajGCDYL8NwkSBY/edit)
- [Master story, eight public wards and Morrow Reach](https://docs.google.com/document/d/1tv4qvdlG6F7EV5EI822OdYgDVbNBwauqiKvNJ2_86Is/edit)
- [Visual development folder](https://drive.google.com/drive/folders/183TPnyaUOVOFHeudg9axc5YaAPodgX1b)
- [Art archive quality notes](https://docs.google.com/document/d/1roYu1Frb2awFvwSI7mms2_llnag58qDVCmnUEfb5F24/edit)

Preliminary SVGs in Drive are reference-only and contain simplifications. This project does not overwrite or delete source artwork in Google Drive.
