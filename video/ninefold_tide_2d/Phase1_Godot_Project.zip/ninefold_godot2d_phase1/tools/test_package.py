#!/usr/bin/env python3
"""Structural checks of the Godot-first studio package; does not waive art approval."""
from qa_assets import ROOT,check
c,w,problems,rows=check()
assert len(c['characters'])==20
assert len(w['locations'])==15
assert len({x['id'] for x in c['characters']})==20
assert len({x['id'] for x in w['locations']})==15
assert set(x['name'] for x in c['characters']) >= {'Naya Venn','Mari','Supervisor Ren'}
for x in c['characters']:
  assert (ROOT/'scenes/characters'/f"{x['id']}.tscn").is_file()
for x in w['locations']:
  assert (ROOT/'scenes/world'/f"{x['id']}.tscn").is_file()
assert len(problems)==35, 'A source claim or artwork approval changed; inspect QA before using it.'
print('Structural test PASS: 20 character rig sockets and 15 environment scene sockets exist. Art production gate deliberately remains BLOCKED.')
