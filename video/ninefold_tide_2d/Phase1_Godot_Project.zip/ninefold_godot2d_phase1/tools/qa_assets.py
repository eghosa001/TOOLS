#!/usr/bin/env python3
"""No-cost quality gate. Strict mode exits nonzero until ALL art and signoffs exist."""
import argparse, json, pathlib, sys, csv
ROOT=pathlib.Path(__file__).resolve().parents[1]

def check():
    c=json.loads((ROOT/'data/cast.json').read_text(encoding='utf8'))
    w=json.loads((ROOT/'data/world.json').read_text(encoding='utf8'))
    problems=[]
    status=[]
    for x in c['characters']:
        base=ROOT/'assets/characters'/x['id']
        ch=json.loads((base/'art_checklist.json').read_text(encoding='utf8'))
        rg=json.loads((base/'rig_calibration.json').read_text(encoding='utf8'))
        missing=[p for field in ['view_files','part_files','expression_files','hand_files'] for p in ch[field] if not (base/p).is_file()]
        missing += [key for key,val in rg['part_pivots'].items() if val is None]
        missing += [key for key,val in rg['part_offsets'].items() if val is None]
        missing += [key for key,val in ch['approvals'].items() if val is not True]
        if not rg.get('approved',False):missing.append('rig_approval')
        if missing:problems.append(('character',x['id'],missing))
        status.append({'kind':'character','name':x['name'],'asset_files_missing':sum(not (base/p).is_file() for f in ['view_files','part_files','expression_files','hand_files'] for p in ch[f]),'status':'BLOCKED' if missing else 'READY'})
    for x in w['locations']:
        base=ROOT/'assets/world'/x['id']; d=json.loads((base/'art_checklist.json').read_text(encoding='utf8'))
        missing=[p for p in d['plates'] if not (base/p).is_file()]
        missing += [key for key,val in d['approval'].items() if val is not True]
        if missing:problems.append(('world',x['id'],missing))
        status.append({'kind':'world','name':x['name'],'asset_files_missing':sum(not (base/p).is_file() for p in d['plates']),'status':'BLOCKED' if missing else 'READY'})
    with (ROOT/'QA_STATUS.csv').open('w',encoding='utf-8',newline='') as f:
        cw=csv.DictWriter(f,fieldnames=['kind','name','asset_files_missing','status']);cw.writeheader();cw.writerows(status)
    return c,w,problems,status

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--strict',action='store_true');args=p.parse_args()
    c,w,problems,status=check()
    print(f"Characters registered: {len(c['characters'])}; worlds: {len(w['locations'])}; blocked: {len(problems)}")
    for typ,name,missing in problems:
        print(f"BLOCKED {typ} {name}: {len(missing)} missing files/calibrations/approvals")
    print('QA_STATUS.csv created')
    if args.strict and problems:sys.exit(1)
