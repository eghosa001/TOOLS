@tool
extends Node2D
## Only approved painted 2D background planes; no 3D layout engine.
@export var location_id: String = "service_gallery"
@export var parallax_strength: float = 0.0
const LAYERS: Array[String] = ["sky", "far_distance", "middle_distance", "playable_floor", "foreground_occlusion"]
var layers: Dictionary = {}
var missing: PackedStringArray = PackedStringArray()

func _ready() -> void:
    for child in get_children():
        if child.has_meta("generated_world_layer"):
            child.free()
    layers.clear()
    missing.clear()
    for i in range(LAYERS.size()):
        var name: String = LAYERS[i]
        var path: String = "res://assets/world/%s/%s.png" % [location_id, name]
        var sprite: Sprite2D = Sprite2D.new()
        sprite.name = name
        sprite.set_meta("generated_world_layer", true)
        sprite.centered = false
        sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
        sprite.z_index = i - 2
        add_child(sprite)
        if ResourceLoader.exists(path):
            sprite.texture = load(path)
        else:
            missing.append(name)
        layers[name] = sprite
    if not missing.is_empty():
        push_warning("World %s missing painted layers: %s" % [location_id, ", ".join(missing)])

func set_camera_shift(amount: Vector2) -> void:
    ## Deliberate 2D multiplane motion, only when approved plates exist.
    for i in range(LAYERS.size()):
        var factor: float = parallax_strength * float(i) / float(LAYERS.size() - 1)
        (layers[LAYERS[i]] as Sprite2D).position = -amount * factor

func is_ready_for_production() -> bool:
    return missing.is_empty()
