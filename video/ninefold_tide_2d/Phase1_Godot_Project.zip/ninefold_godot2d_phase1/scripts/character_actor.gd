@tool
extends Node2D
## Production rig SOCKET ONLY. Never synthesizes or deforms unfinished character art.
## The scene is intentionally visually empty until approved layered source PNGs exist.
@export var character_id: String = "naya_venn"
@export var show_missing_warnings: bool = true

const PARTS: Array[String] = ["back_hair", "back_cape", "rear_accessory",
    "left_thigh", "left_calf", "left_foot", "right_thigh", "right_calf", "right_foot",
    "pelvis", "torso", "neck", "head", "left_upper_arm", "left_forearm", "left_hand",
    "right_upper_arm", "right_forearm", "right_hand", "eyes", "brows", "mouth",
    "front_hair", "front_costume", "front_accessory"]
const PARENTS: Dictionary = {
    "left_calf":"left_thigh", "left_foot":"left_calf",
    "right_calf":"right_thigh", "right_foot":"right_calf",
    "torso":"pelvis", "neck":"torso", "head":"neck",
    "left_upper_arm":"torso", "left_forearm":"left_upper_arm", "left_hand":"left_forearm",
    "right_upper_arm":"torso", "right_forearm":"right_upper_arm", "right_hand":"right_forearm",
    "eyes":"head", "brows":"head", "mouth":"head", "front_hair":"head",
    "front_costume":"torso", "front_accessory":"torso"
}
var joints: Dictionary = {}
var calibration: Dictionary = {}
var missing: PackedStringArray = PackedStringArray()

func _ready() -> void:
    _remove_built_nodes()
    var path: String = "res://assets/characters/%s/rig_calibration.json" % character_id
    if FileAccess.file_exists(path):
        var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
        if parsed is Dictionary:
            calibration = parsed
    var pivots: Dictionary = calibration.get("part_pivots", {})
    var offsets: Dictionary = calibration.get("part_offsets", {})
    joints["root"] = self
    for part in PARTS:
        var parent_key: String = str(PARENTS.get(part, "root"))
        var joint: Node2D = Node2D.new()
        joint.name = part
        joint.set_meta("generated_rig_node", true)
        var par: Node2D = joints.get(parent_key, self) as Node2D
        par.add_child(joint)
        joints[part] = joint
        var pivot_data: Variant = pivots.get(part)
        var offset_data: Variant = offsets.get(part)
        if pivot_data is Array and pivot_data.size() == 2:
            joint.position = Vector2(float(pivot_data[0]), float(pivot_data[1]))
        else:
            missing.append("pivot:" + part)
        var sprite: Sprite2D = Sprite2D.new()
        sprite.name = "Art"
        sprite.centered = false
        sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
        joint.add_child(sprite)
        if offset_data is Array and offset_data.size() == 2:
            sprite.position = Vector2(float(offset_data[0]), float(offset_data[1]))
        var art_path: String = "res://assets/characters/%s/parts/%s.png" % [character_id, part]
        if ResourceLoader.exists(art_path):
            sprite.texture = load(art_path)
        else:
            missing.append("art:" + part)
    if show_missing_warnings and not missing.is_empty():
        push_warning("%s is NOT animation ready; missing %d parts/pivots. See art_checklist.json." % [character_id, missing.size()])

func _remove_built_nodes() -> void:
    for child in get_children():
        if child.has_meta("generated_rig_node"):
            child.free()
    joints.clear()
    missing.clear()

func set_expression(expression_name: String) -> bool:
    ## Prefer separately approved replacement face drawings. No generative morphing.
    var path: String = "res://assets/characters/%s/expressions/%s.png" % [character_id, expression_name]
    if not ResourceLoader.exists(path) or not joints.has("head"):
        return false
    var joint: Node2D = joints["head"] as Node2D
    var face: Sprite2D = joint.get_node_or_null("Expression") as Sprite2D
    if face == null:
        face = Sprite2D.new()
        face.name = "Expression"
        joint.add_child(face)
    face.texture = load(path)
    face.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS
    return true

func set_hand(side: String, variant: String) -> bool:
    if side != "left" and side != "right":
        return false
    var path: String = "res://assets/characters/%s/hands/%s_%s.png" % [character_id, side, variant]
    if not ResourceLoader.exists(path):
        return false
    var joint: Node2D = joints.get(side + "_hand") as Node2D
    if joint == null:
        return false
    var sprite: Sprite2D = joint.get_node("Art") as Sprite2D
    sprite.texture = load(path)
    return true

func set_pose(rotations_degrees: Dictionary) -> void:
    ## Artist keyframes set joint rotations; silhouette redraws replace this for large turns.
    for part in rotations_degrees.keys():
        if joints.has(part):
            (joints[part] as Node2D).rotation_degrees = float(rotations_degrees[part])

func is_ready_for_production() -> bool:
    return missing.is_empty() and bool(calibration.get("approved", false))
